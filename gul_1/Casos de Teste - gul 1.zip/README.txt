Arquivo zip gerado em: 31/03/2023 08:56:30 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: gul 1